#!/bin/sh
PYTHONPATH=../.. python -m lark.tools.standalone json.lark > json_parser.py
