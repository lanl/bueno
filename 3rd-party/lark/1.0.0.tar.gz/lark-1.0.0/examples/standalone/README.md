# Standalone example

To initialize, cd to this folder, and run:


```bash
	 ./create_standalone.sh
```

Or:
```bash
python -m lark.tools.standalone json.lark > json_parser.py
````

Then run using:

```bash
python json_parser_main.py <path-to.json>
```

