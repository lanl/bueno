Thank you for using Pika.

- IMPORTANT -----------------------------------------------------------
STOP NOW AND READ THIS BEFORE OPENING A NEW ISSUE ON GITHUB
--------------------------------------------------------------------------

Unless you are CERTAIN you have found a reproducible bug in Pika, you must
first ask your question, discuss your suspected issue, or propose your new
feature on the mailing list:

https://groups.google.com/forum/#!forum/pika-python

Pika's maintainers do NOT use GitHub issues for questions, root cause analysis,
conversations, code reviews, etc.

Thank you!
