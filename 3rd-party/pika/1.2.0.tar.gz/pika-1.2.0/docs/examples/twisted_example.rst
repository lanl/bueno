Twisted Consumer Example
========================
Example of writing an application using the :py:class:`Twisted connection adapter <pika.adapters.twisted_connection.TwistedProtocolConnection>`::.

`Twisted Example <https://github.com/pika/pika/blob/master/examples/twisted_service.py>`_
