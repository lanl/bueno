Exceptions
==========
.. automodule:: pika.exceptions
   :members:
   :undoc-members:
