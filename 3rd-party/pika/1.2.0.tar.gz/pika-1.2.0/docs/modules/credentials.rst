Authentication Credentials
==========================
.. automodule:: pika.credentials

PlainCredentials
----------------
.. autoclass:: PlainCredentials
   :members:
   :inherited-members:
   :noindex:

ExternalCredentials
-------------------
.. autoclass:: ExternalCredentials
   :members:
   :inherited-members:
   :noindex:

